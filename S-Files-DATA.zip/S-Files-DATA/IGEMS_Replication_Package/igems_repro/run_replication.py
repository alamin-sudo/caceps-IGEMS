"""
IGEMS replication driver.

Regenerates every table and figure-input from the documented model, writes
them to ./outputs/, and validates the computed values against the published
dataset. Run:

    python run_replication.py

Outputs (CSV) and a plain-text validation report are written to ./outputs/.
"""

from __future__ import annotations
import os
import pandas as pd
import igems_model as ig

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "outputs")
os.makedirs(OUT, exist_ok=True)


def _w(df, name):
    path = os.path.join(OUT, name)
    df.to_csv(path, index=False)
    return path


def main():
    baseline = ig.load_baseline()
    base = ig.load_base_allocations()
    compliance = ig.load_compliance_summary()
    report = []

    def check(label, computed, published, tol):
        ok = abs(float(computed) - float(published)) <= tol
        report.append(f"  [{'PASS' if ok else 'CHECK'}] {label}: "
                      f"computed={computed:.3f}  published={published:.3f}  tol={tol}")
        return ok

    report.append("IGEMS replication validation report")
    report.append("=" * 60)

    # 1. Market allocation reproduced from the grandfathering formula
    report.append("\n1. Market-based allocation (grandfathering formula vs published)")
    mkt = ig.allocate_market(baseline)
    for region in baseline.index:
        check(f"market alloc {region}", mkt.loc[region],
              base.loc[region, "market_alloc_Gt"], 0.02)

    # 2. Static allocation table (Table 2)
    tbl2 = ig.allocation_table(baseline, base).reset_index()
    _w(tbl2, "table2_static_allocation.csv")
    report.append("\n2. Hybrid allocation (0.40 market + 0.35 equity + 0.25 capacity vs published)")
    hyb = ig.allocate_hybrid(base)
    published_hybrid = {"North America":1.34,"Europe":1.02,"China":2.13,"India":1.72,
                        "Sub-Saharan Africa":1.75,"Middle East & C.Asia":0.69,
                        "South Asia":1.84,"East Asia & Pacific":1.95,"Latin America":1.83}
    for region, pub in published_hybrid.items():
        check(f"hybrid alloc {region}", hyb.loc[region], pub, 0.02)

    # 3. Per-capita and inequality ratios
    report.append("\n3. Per-capita inequality (max/min ratio)")
    check("market per-capita ratio", ig.per_capita_ratio(mkt, baseline), 11.07, 0.2)
    check("hybrid per-capita ratio", ig.per_capita_ratio(hyb, baseline), 3.065, 0.1)
    pc = pd.DataFrame({
        "region": baseline.index,
        "market_t_per_person": ig.per_capita(mkt, baseline).round(2).values,
        "equity_t_per_person": ig.per_capita(base["equity_alloc_Gt"], baseline).round(2).values,
        "capacity_t_per_person": ig.per_capita(base["capacity_alloc_Gt"], baseline).round(2).values,
        "hybrid_t_per_person": ig.per_capita(hyb, baseline).round(2).values,
        "benchmark": round(ig.PER_CAPITA_BENCHMARK, 2),
    })
    _w(pc, "percapita.csv")

    # 4. Justice index (documented formula, self-consistent)
    ji = pd.DataFrame({
        "region": baseline.index,
        "market_JI": ig.justice_index(mkt, baseline).values,
        "equity_JI": ig.justice_index(base["equity_alloc_Gt"], baseline).values,
        "capacity_JI": ig.justice_index(base["capacity_alloc_Gt"], baseline).values,
        "hybrid_JI": ig.justice_index(hyb, baseline).values,
    })
    _w(ji, "justice_index.csv")

    # 5. 50-year summary (Table 3)
    report.append("\n4. Fifty-year summary (Table 3): compliance -> success probability")
    tbl3 = ig.summary_50yr(base, compliance)
    _w(tbl3, "table3_summary.csv")
    pub_prob = {"market":0.20,"equity":0.50,"capacity":0.50,"hybrid":0.85}
    for _, row in tbl3.iterrows():
        check(f"success prob {row['mechanism']}",
              row["success_probability_1p5C"], pub_prob[row["mechanism"]], 0.001)
    check("total reduction 2024-2074", float(tbl3["total_reduction"].iloc[0]), 0.702, 0.02)

    # 6. Trajectory (Figure inputs)
    traj = ig.trajectory()
    _w(traj, "trajectory.csv")
    report.append("\n5. Physical trajectory endpoint")
    report.append(f"     2074 emissions (formula) = {traj['global_emissions_Gt'].iloc[-1]:.2f} Gt")

    # 7. Weighting-grid sensitivity (Table 5)
    report.append("\n6. Weighting-grid sensitivity (Table 5): required cuts")
    wg = ig.weighting_grid(base, baseline)
    _w(wg, "table5_weighting_grid.csv")
    pub_na_cut = {"30:50:20":0.825, "40:35:25":0.793, "50:25:25":0.772}
    for _, row in wg.iterrows():
        if row["weighting_M:E:C"] in pub_na_cut:
            check(f"NA cut {row['weighting_M:E:C']}",
                  row["north_america_cut"], pub_na_cut[row["weighting_M:E:C"]], 0.01)

    # 8. Decarbonization-rate sensitivity (Figure 4B)
    report.append("\n7. Decarbonization-rate sensitivity (2074 endpoints)")
    ds = ig.decarbonization_sensitivity()
    _w(ds, "sensitivity_decarb.csv")
    pub_endpoints = {0.015:17.0, 0.020:13.18, 0.025:10.20, 0.030:7.89, 0.035:6.11}
    for _, row in ds.iterrows():
        check(f"2074 endpoint at rate {row['decarbonization_rate']}",
              row["emissions_2074_Gt"], pub_endpoints[row["decarbonization_rate"]], 0.05)

    # 9. Budget sensitivity (Figure 4A) passthrough
    _w(ig.budget_sensitivity(), "sensitivity_budget.csv")

    # Notes on known source inconsistencies (so replicators are not surprised)
    report.append("\n" + "=" * 60)
    report.append("Notes on known source inconsistencies (see README, 'Caveats'):")
    report.append("  - Manuscript text cites a hybrid per-capita ratio of 4.4; the supplied")
    report.append("    dataset yields 3.07 (base weighting). The code computes 3.07.")
    report.append("  - Table 3 reports a 2074 endpoint of 10.8 Gt; the (1-r)^50 formula")
    report.append("    yields 10.20 Gt. The code computes 10.20.")
    report.append("  - Equity allocations sum to 11.03 Gt and capacity to 25.65 Gt; neither")
    report.append("    is normalized to the 10 Gt budget. They are used as provided.")
    report.append("  - The published Justice Index column was produced by the author's")
    report.append("    spreadsheet and differs from the documented formula in a few cells.")
    report.append("    The code applies the documented formula uniformly.")

    text = "\n".join(report)
    with open(os.path.join(OUT, "validation_report.txt"), "w") as f:
        f.write(text + "\n")
    print(text)
    print("\nAll outputs written to:", OUT)


if __name__ == "__main__":
    main()
