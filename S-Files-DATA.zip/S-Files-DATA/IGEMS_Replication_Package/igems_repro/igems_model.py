"""
IGEMS: Integrated Global Emissions Management System
Reference model implementation for replication.

This module reproduces the quantitative results reported in:
  Al-Amin, A. Q. "The Governance Sequence Drives a Fourfold Difference
  in 1.5C Compatibility: A Computational Framework for Equitable Global
  Carbon Budget Allocation."

IGEMS is a governance-allocation simulator, not an integrated assessment
model. It takes the global carbon budget as an external input and compares
four allocation mechanisms under identical physical assumptions. The point
of the design is channel isolation: all mechanisms share the same budget,
the same decarbonization rate, and the same technology, so any difference in
outcome is attributable to the governance channel alone.

Dependencies: numpy, pandas (see requirements.txt).
Python 3.9 or newer.
"""

from __future__ import annotations
import os
import numpy as np
import pandas as pd

# --------------------------------------------------------------------------
# Model constants (manuscript base case)
# --------------------------------------------------------------------------
ANNUAL_BUDGET_GT = 10.0      # global annual budget, Gt CO2 per year
DECARB_RATE = 0.025          # uniform annual decarbonization rate
START_YEAR = 2024
END_YEAR = 2074              # 50-year horizon
BASE_GLOBAL_EMISSIONS = 36.2  # Gt CO2 in 2024 (sum of regional current emissions)

# Per-capita parity benchmark, t CO2 per person per year.
# NOTE: the manuscript benchmark uses an effective population of 7.87 billion
# (10 Gt / 7.87 B = 1.27 t/person). This differs from the regional population
# sum in the baseline (10.05 B). The 7.87 B figure is the published benchmark
# basis and is retained here for exact reproduction. See README, "Caveats".
BENCHMARK_POPULATION_B = 7.87
PER_CAPITA_BENCHMARK = ANNUAL_BUDGET_GT / BENCHMARK_POPULATION_B  # ~= 1.2706

# Hybrid cooperative weighting (market : equity : capacity).
HYBRID_WEIGHTS = {"market": 0.40, "equity": 0.35, "capacity": 0.25}

# Compliance-conditioned 1.5C success-probability bands.
# At a fixed budget the physical endpoint is shared, so the realized mean
# compliance rate (CR) discriminates between mechanisms.
def success_probability(mean_compliance: float) -> float:
    """Map a mean regional compliance rate to a heuristic 1.5C success probability."""
    cr = float(mean_compliance)
    if cr > 0.70:
        return 0.85
    if cr >= 0.40:
        return 0.50
    return 0.20


# --------------------------------------------------------------------------
# Data loading
# --------------------------------------------------------------------------
def _data_dir(data_dir=None):
    return data_dir or os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")


def load_baseline(data_dir=None) -> pd.DataFrame:
    """Load the 9-region baseline (population, GDP, emissions, forest, etc.)."""
    df = pd.read_csv(os.path.join(_data_dir(data_dir), "baseline_regions.csv"))
    return df.set_index("region")


def load_base_allocations(data_dir=None) -> pd.DataFrame:
    """Load the market, equity, and capacity allocation vectors (Gt CO2/yr).

    The market vector is reproducible in closed form (see allocate_market).
    The equity and capacity vectors are produced by the IGEMS allocation
    routine described in the manuscript Methods (Sections 3.4). They are
    supplied here as canonical model inputs so that all downstream results
    reproduce exactly. allocate_market() below regenerates the market vector
    and the driver validates it against this file.
    """
    df = pd.read_csv(os.path.join(_data_dir(data_dir), "base_allocations.csv"))
    return df.set_index("region")


def load_compliance_summary(data_dir=None) -> dict:
    """Load the 50-year mean compliance rate per mechanism (Table 3)."""
    df = pd.read_csv(os.path.join(_data_dir(data_dir), "compliance_summary.csv"))
    return dict(zip(df["mechanism"], df["mean_compliance"]))


# --------------------------------------------------------------------------
# Allocation mechanisms
# --------------------------------------------------------------------------
def allocate_market(baseline: pd.DataFrame, budget=ANNUAL_BUDGET_GT) -> pd.Series:
    """Market-based (grandfathering) allocation.

    Each region keeps its current share of global emissions, scaled to the
    budget:  A_market_i = E_current_i * (budget / sum_j E_current_j).
    This imposes a uniform proportional cut and preserves the current
    emissions hierarchy.
    """
    e = baseline["current_emissions_GtCO2"]
    return e * (budget / e.sum())


def allocate_hybrid(base: pd.DataFrame, weights=HYBRID_WEIGHTS) -> pd.Series:
    """Hybrid cooperative allocation: weighted blend of the three base vectors.

    A_hybrid_i = w_m * A_market_i + w_e * A_equity_i + w_c * A_capacity_i.
    """
    return (weights["market"] * base["market_alloc_Gt"]
            + weights["equity"] * base["equity_alloc_Gt"]
            + weights["capacity"] * base["capacity_alloc_Gt"])


def allocation_table(baseline: pd.DataFrame, base: pd.DataFrame) -> pd.DataFrame:
    """Assemble the full static allocation table (manuscript Table 2)."""
    out = pd.DataFrame(index=baseline.index)
    out["current_Gt"] = baseline["current_emissions_GtCO2"]
    out["market_Gt"] = base["market_alloc_Gt"]
    out["equity_Gt"] = base["equity_alloc_Gt"]
    out["capacity_Gt"] = base["capacity_alloc_Gt"]
    out["hybrid_Gt"] = allocate_hybrid(base).round(3)
    # required reduction from current emissions, per mechanism
    for m in ["market", "equity", "capacity", "hybrid"]:
        red = 1.0 - out[f"{m}_Gt"] / out["current_Gt"]
        out[f"{m}_reduction"] = red.clip(lower=0.0).round(3)  # 0 = development surplus
    return out


# --------------------------------------------------------------------------
# Equity / justice metrics
# --------------------------------------------------------------------------
def per_capita(allocation_Gt: pd.Series, baseline: pd.DataFrame) -> pd.Series:
    """Per-capita allocation in t CO2 per person per year (alloc Gt / pop billion)."""
    return allocation_Gt / baseline["population_billion"]


def justice_index(allocation_Gt: pd.Series, baseline: pd.DataFrame,
                  benchmark=PER_CAPITA_BENCHMARK) -> pd.Series:
    """Justice Index = 100 - |percap - benchmark| / benchmark * 100, floored at 0.

    100 denotes perfect per-capita parity. The documented formula is applied
    uniformly here, so values are internally self-consistent across mechanisms.
    """
    pc = per_capita(allocation_Gt, baseline)
    dev = (pc - benchmark).abs() / benchmark
    return (100.0 - dev * 100.0).clip(lower=0.0).round(1)


def development_surplus(allocation_Gt: pd.Series, baseline: pd.DataFrame) -> pd.Series:
    """Development surplus = allocation minus current emissions, where positive.

    A positive value means the mechanism grants a region room to grow above
    its current emissions (e.g. equity allocations for populous low-income
    regions).
    """
    return (allocation_Gt - baseline["current_emissions_GtCO2"]).clip(lower=0.0).round(3)


def per_capita_ratio(allocation_Gt: pd.Series, baseline: pd.DataFrame) -> float:
    """Max/min per-capita ratio across regions (inequality measure)."""
    pc = per_capita(allocation_Gt, baseline)
    return float(pc.max() / pc.min())


# --------------------------------------------------------------------------
# Dynamic simulation
# --------------------------------------------------------------------------
def trajectory(rate=DECARB_RATE, e0=BASE_GLOBAL_EMISSIONS,
               start=START_YEAR, end=END_YEAR) -> pd.DataFrame:
    """Global emission trajectory: E_t = E0 * (1 - rate) ** (t - start).

    The physical trajectory is identical across mechanisms by construction,
    because all share the same decarbonization rate. This is the core of the
    channel-isolation design.
    """
    years = np.arange(start, end + 1)
    e = e0 * (1.0 - rate) ** (years - start)
    return pd.DataFrame({"year": years, "global_emissions_Gt": np.round(e, 3)})


def summary_50yr(base: pd.DataFrame, compliance: dict,
                 rate=DECARB_RATE, e0=BASE_GLOBAL_EMISSIONS) -> pd.DataFrame:
    """50-year simulation summary per mechanism (manuscript Table 3)."""
    traj = trajectory(rate=rate, e0=e0)
    e_end = float(traj["global_emissions_Gt"].iloc[-1])
    total_reduction = 1.0 - e_end / e0
    rows = []
    for m in ["market", "equity", "capacity", "hybrid"]:
        cr = compliance[m]
        rows.append({
            "mechanism": m,
            "emissions_2024_Gt": round(e0, 1),
            "emissions_2074_Gt": round(e_end, 2),
            "total_reduction": round(total_reduction, 3),
            "mean_compliance": cr,
            "success_probability_1p5C": success_probability(cr),
        })
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------
# Sensitivity analyses
# --------------------------------------------------------------------------
def weighting_grid(base: pd.DataFrame, baseline: pd.DataFrame,
                   grids=((0.30, 0.50, 0.20), (0.40, 0.35, 0.25), (0.50, 0.25, 0.25))) -> pd.DataFrame:
    """Weighting-grid sensitivity of the hybrid mechanism (manuscript Table 5).

    Recombines the same three base vectors under alternative weights and
    reports required cuts and the per-capita inequality ratio.
    """
    rows = []
    for wm, we, wc in grids:
        w = {"market": wm, "equity": we, "capacity": wc}
        hyb = allocate_hybrid(base, weights=w)
        cur = baseline["current_emissions_GtCO2"]
        red = (1.0 - hyb / cur).clip(lower=0.0)
        ji = justice_index(hyb, baseline)
        rows.append({
            "weighting_M:E:C": f"{int(wm*100)}:{int(we*100)}:{int(wc*100)}",
            "north_america_cut": round(float(red.loc["North America"]), 3),
            "europe_cut": round(float(red.loc["Europe"]), 3),
            "india_cut": round(float(red.loc["India"]), 3),
            "max_min_per_capita": round(per_capita_ratio(hyb, baseline), 2),
            "avg_justice_index": round(float(ji.mean()), 1),
        })
    return pd.DataFrame(rows)


def decarbonization_sensitivity(rates=(0.015, 0.020, 0.025, 0.030, 0.035),
                                compliance_gap_pp=56,
                                e0=BASE_GLOBAL_EMISSIONS) -> pd.DataFrame:
    """Decarbonization-rate sensitivity (manuscript Section 3.9, Figure 4B).

    Reports the 2074 endpoint for each rate. The hybrid-versus-market
    compliance gap is held at 56 percentage points: it is a governance
    property, independent of the physical decarbonization rate.
    """
    rows = []
    for r in rates:
        e_end = e0 * (1.0 - r) ** (END_YEAR - START_YEAR)
        rows.append({
            "decarbonization_rate": r,
            "emissions_2074_Gt": round(e_end, 2),
            "below_5Gt_threshold": e_end < 5.0,
            "compliance_gap_pp": compliance_gap_pp,
        })
    return pd.DataFrame(rows)


def budget_sensitivity(data_dir=None) -> pd.DataFrame:
    """Carbon-budget sensitivity grid (manuscript Section 3.9, Figure 4A)."""
    return pd.read_csv(os.path.join(_data_dir(data_dir), "sensitivity_budget.csv"))
